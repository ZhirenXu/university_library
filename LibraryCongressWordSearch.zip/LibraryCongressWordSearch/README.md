# LibraryOfCongress-Subject-Name-Scrapper
A script that can scrapes terms from LOC for library use.

Base on  https://github.com/ruthtillman/subjectreconscripts

User can choose search mode and generate a csv file as output.
Currently support LCNAF and LCSH searching.