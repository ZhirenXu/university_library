categoryList = ["f[admin_set_sim][]", "f[collection_name_sim][]", "f[sub_collection_sim][]",
                "f[resource_type_sim][]", "f[creator_sim][]", "f[keyword_sim][]", "f[subject_sim][]",
                "f[format_sim][]", "f[work_type_sim][]", "f[language_sim][]", "f[spatial_sim][]",
                "f[publisher_sim][]", "f[temporal_sim][]"]
