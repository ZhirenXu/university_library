import ParseUrl
import GetCollectionName
import GetMaxRecords
import GetJson
import GetNextPage
import CreateIDList
import concurrent.futures
import sys
def ParallelParseUrl(urlList):
    with concurrent.futures.ThreadPoolExecutor() as parseExecutor:
        future_to_url = {parseExecutor.submit(ParseUrl.parseUrl, url): url for url in urlList}
    return   concurrent.futures.as_completed(future_to_url)

def ParallelProcess(parsedUrlThread, idList):
    idCombine = []
    with concurrent.futures.ThreadPoolExecutor() as jsonExecutor:
        for future in parsedUrlThread:
            #print ("\n", future.result)
            future_to_json = {jsonExecutor.submit(runProcess, future.result(), idList): future}
            idList = []
        #sys.exit()
        #print("\n", future_to_json)
    for futureResult in future_to_json:
        idCombine += CreateIDList.createIDList(futureResult.result())
        #sys.exit()
    return idCombine

##Main function of ID scrapper
# @param    urlList
#           A list of url that need to be processed
# @param    idList
#           A list that contain Json ID

def runProcess(parsedUrl, idList):
    idListCombine = []
    #i = 0
    #j = 0

    #for future in concurrent.futures.as_completed(future_to_url):
    #parsedUrl = future.result()
    # find the name of collection
    collectionTitle = GetCollectionName.getCollectionName(parsedUrl)
    # find how many records in this collection
    tag = parsedUrl.find('meta', attrs={'name': "totalResults"})
    numOfRecords = int(tag['content'])
    remainRecords = numOfRecords
    # find 100-per-page link
    maxRecordLink = GetMaxRecords.getMaxRecords(parsedUrl)
    nextLink = maxRecordLink
    # after get that link, read json data from it
    while remainRecords > 0:
        parsedNextLink = GetJson.getJson(nextLink, idList)
        nextPage = GetNextPage.getNextPage(parsedNextLink)
        nextLink = nextPage
        remainRecords = numOfRecords - len(idList)
        print(remainRecords)
        print("Number of id scrapped: ", len(idList), "\n")
    #i += 1
    #idListCombine = CreateIDList.createIDList(i, j, idList, idListCombine)
    #idList = []
    #print(i, "/", len(urlList), " has been processed.\n")
    return idList
