import json
import csv
import requests
import Greeting
import RunProcess
import SimpleCSV
import WriteCSV
        
def main():
    pageUrl = []
    csvCategory = []
    idList = []
    idListCombine = []
    outputList = []
    remainRecords = 0

    Greeting.showInfo()
    # get inputfile
    fileIn = SimpleCSV.getCSVInput()
    # get outputfile
    fileOut = SimpleCSV.getCSVOutput()
    
    pageUrl = SimpleCSV.readCSV(fileIn)
    numOfUrl = len(pageUrl)
    print("There are ", numOfUrl, " records in the input file.")
    # parse url from input file in parallel
    parsedThreadFuture = RunProcess.ParallelParseUrl(pageUrl)
    # id scrap
    idListCombine = RunProcess.ParallelProcess(parsedThreadFuture, idList)
    # write data to csv file
    print("Writing identifiers into ", fileOut, "...")
    outFile = open(fileOut, 'w', encoding = 'utf8', newline='')
    SimpleCSV.writeCSV(idListCombine, outFile)
    
    # program exit
    Greeting.sysExit(fileOut)
    
if __name__ == "__main__":
    main()
