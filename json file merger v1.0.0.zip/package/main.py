import sys
import GetKey
import CountJson
import GetKeyData
import MergeJson
import GetOutput
import GetOtherData

def main():
    key = ""
    output = ""
    jsonList = []
    billDetailList = []
    miscDetailList = []
    i = 0
    fileNum = 0
    
    # ask for desired keys that contain useful data
    key = GetKey.getKey()
    output = GetOutput.getOutput()
    # show how many files in and scraped keyword
    fileNum = CountJson.countJson(jsonList)
    # get other content in first json
    GetOtherData.getOtherData(key, jsonList[0], miscDetailList, fileNum);
    # open json file one by one
    for json in jsonList:
        # get Json header(category name), data into seperate list
        print("Current File: ", json, end = "")
        GetKeyData.getKeyData(key, json, billDetailList)
        print("    ...Done\n")
    # merge bill detain into one json
    print("Total number of json: ", len(jsonList), "    ", "Total number of bills scraped: ", len(billDetailList))
    MergeJson.mergeJson(output, key, miscDetailList, billDetailList)
    # program exit
    print("Merge Complete. Output file name is: ", output, " Press enter to exit.")
    key = input()
    sys.exit()
    
if __name__ == "__main__":
    main()
