import unittest
from package import CountJson

class TestCountJson(unittest.TestCase):

    def test_count_json(self):
        j_list = []
        print("start testing...")    
        CountJson.countJson(j_list)
        print(j_list)

if __name__ == '__main__':
    unittest.main()
