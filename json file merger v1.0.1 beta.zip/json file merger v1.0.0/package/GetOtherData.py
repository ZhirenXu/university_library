import os
import json

## Get json data using key for a specific json file and store in a dict
# @param    key
#           Key of a dict in json file that contain useful value
# @param    jsonFile
#           the file that we extract data from
# @param    miscList
#           A list contain all tuples that have different key cmp to @key
# @param    jsonHeader
#	    A dict contain status and copy right info
# @param    fileNum
#           how many json file in this directory
def getOtherData(key, jsonFile, miscList, jsonHeader, fileNum):
    resultKeyList = []
    resultDict = {}
    miscDict= {}
    
    file = open(jsonFile, 'r')
    
    jsonContent = json.load(file)
    jsonHeader["status"] = jsonContent["status"]
    jsonHeader["copyright"] = jsonContent["copyright"]
    jsonContentResults = jsonContent["results"]
    resultDict = jsonContentResults[0]
    
    resultKeyList = resultDict.keys()
    for miscKey in resultKeyList:
        if (miscKey != key):
            if (miscKey != "offset"):
                miscDict[miscKey] = resultDict.get(miscKey)
    miscDict["num_results"] = len(miscDict["results"][key])
    miscList.append(miscDict)
    file.close()
