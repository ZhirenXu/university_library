import os
import json

## merge all elements in billDetailList into target file, under the value of key
# @param    outFile
#           the output file name
# @param    key
#           the key of a tuple in target json
# @param    miscDetailList
#           a list conatins other common dicts in json files
# @param    jsonHeader
#	    A dict contain status and copy right info
# @param    numOfBills
#           How many jsons get merged
# @param    billDetailList
#           a list contains all values for tuple with @key as key
def mergeJson(outFile, key, miscDetailList, jsonHeader, numOfBills, billDetailList):
    # the dict which combines everything, ready to be dump into json file
    rootDict = {}
    resultDict = {}
    resultList = []
    rootDict.update(jsonHeader)
    
    resultDict = miscDetailList[0]
    resultDict[key] = billDetailList
    resultDict["num_results"] = numOfBills
    #print(resultDict)
    resultList.append(resultDict)
    rootDict["results"] = resultList
    # write both dicts into new json
    tar = open(outFile, 'w')
    json.dump(rootDict, tar)
    # close file
    tar.close()
    
