import unittest
from package import GetJsonData

class TestGetJsonData(unittest.TestCase):

    def test_Get_Json_Data(self):
        jsonFile = ["kilroy_p9.json"]
        key = 'bills'
        billList = []
        
        print("start testing...")
        for file in jsonFile:
            GetJsonData.getJsonData(key, file, billList)

if __name__ == '__main__':
    unittest.main()
