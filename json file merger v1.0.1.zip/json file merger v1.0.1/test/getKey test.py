import unittest
from package import GetKey

class TestGetKey(unittest.TestCase):

    def test_get_key(self):
        print("start testing...")
        ret = GetKey.getKey()
        print("Return value is: ", ret)

if __name__ == '__main__':
    unittest.main()
