Instruction to Use:
	1. put json files under 'package' folder (NOT 'file' folder- that's for testing json files)
	2. run 'main.py'
	3. output file will also in 'package' folder