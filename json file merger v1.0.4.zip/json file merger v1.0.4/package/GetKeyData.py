import os
import json

## Get json data using key for a specific json file
# and store in a dict
# @param    key
#           Key of a dict in json file that contain useful value
# @param    jsonFile
#           the file that we extract data from
# @param    detailList
#           A list contain all tuples under the key
def getKeyData(key, jsonFile, detailList):
    hasKey = False
    
    file = open(jsonFile, 'r')
    jsonContent = json.load(file)
    jsonContentResults = jsonContent["results"]
    for dict_ in jsonContentResults:
        if(key in dict_):
            detailList += dict_[key]
            break;
    file.close()
    if (len(detailList) > 0):
        hasKey = True

    return hasKey
