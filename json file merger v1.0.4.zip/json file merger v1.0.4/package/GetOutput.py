import sys

## get output file name
# @return   output
#           the desired output name of merged json file in string
def getOutput():
    print("Please enter the name of merged json files(do not include .json): ", end = "")
    out = input()
    out += ".json"
    return out
    
