import sys

## get output CSV file name
# @return   output
#           the desired output name of CSV file in string
def getOutputCSV():
    print("Please enter the name of output CSV files(do not include .csv): ", end = "")
    out = input()
    out += ".csv"
    return out
