import sys

# display welcome message
def greeting():
    print("************JSON File Merger for ProPublica Congress API v1.0.4************\n Author: Zhiren Xu\n")
    
