import json
import pandas as pd
import WriteCSV
from pandas import json_normalize

## use pandas to normalize output json by client's requirement
# @param    output
#           an output json file with all data we need
# @param    outCSV
#           
def prettyOutput(output, outCSV):
    with open(output) as f:
        jsonData = json.load(f)
        dataFrame = json_normalize(data = jsonData['results'], record_path='bills', meta=['id', 'member_uri', 'name','num_results'])
        print(dataFrame)
    f.close()
    print("Write normalized Json data into CSV file...")
    WriteCSV.writeCSV(dataFrame, outCSV)
    
