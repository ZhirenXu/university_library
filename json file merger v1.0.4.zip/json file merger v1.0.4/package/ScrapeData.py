import GetKeyData
import os

## scrape data by keywords for every json files
# @param    jsonList
#           a list contain all target json files
# @param    key
#           The key of tuples taht contain desired data
# @param    billDetailList
#           A list contain all tuples under the key
def scrapeData(jsonList, key, billDetailList):
    for json in jsonList:
        # get Json header(category name), data into seperate list
        print("Current File: ", json, end = "")
        hasKey = GetKeyData.getKeyData(key, json, billDetailList)
        print("    ...Done\n")
    if (not hasKey):
        print("Error: no key word has found in these json files. Please check typo or input correct file.")
        print("Press enter to exit...", end = "")
        key = input()
        sys.exit()
