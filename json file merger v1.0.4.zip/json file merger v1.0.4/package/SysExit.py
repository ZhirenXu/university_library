import sys

## Prompt message when program finished and wait for program exit
# @param    outFile
#           name of output csv file
# @param    outCSV
#           name of output csv file
def sysExit(outFile, outCSV):
    print("Merge Complete. The output json file is: ", outFile, " . The output CSV file is ", outCSV, ". ", "\nIt is located in the same folder with your main.py program. Press enter to exit.")
    key = input()
    sys.exit()
