import sys
from pandas import DataFrame

# write dataFrame from json.normalize into csv file
# @param    dataFrame
#           normalized json data in dataFrame format
# @param    outFile
#           out File pointed by user

def writeCSV(dataFrame, outfile):
    dataFrame.to_csv(outfile, na_rep = "null", encoding = 'utf8')
