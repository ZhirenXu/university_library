import sys
import Greeting
import GetKey
import CountJson
import ScrapeData
import MergeJson
import GetOutput
import GetOutputCSV
import GetOtherData
import PrettyOutput
import SysExit

def main():
    key = ""
    outputJson = ""
    outputCSV = ""
    jsonList = []
    billDetailList = []
    miscDetailList = []
    jsonHeader = {}
    i = 0
    fileNum = 0
    numOfBills = 0
    hasKey = True
    
    # ask for desired keys that contain useful data
    Greeting.greeting()
    key = GetKey.getKey()
    outputJson = GetOutput.getOutput()
    outputCSV = GetOutputCSV.getOutputCSV()
    # show how many files in and scraped keyword
    fileNum = CountJson.countJson(jsonList)
    # get other content in first json
    GetOtherData.getOtherData(key, jsonList[0], miscDetailList, jsonHeader, fileNum);
    ScrapeData.scrapeData(jsonList, key, billDetailList)
    # merge bill detain into one json
    numOfBills = len(billDetailList)
    print("Total number of json: ", len(jsonList), "    ", "Total number of bills scraped: ", len(billDetailList), "\n")
    MergeJson.mergeJson(outputJson, key, miscDetailList, jsonHeader, numOfBills, billDetailList)
    # normalize output
    PrettyOutput.prettyOutput(outputJson, outputCSV)
    # program exit
    SysExit.sysExit(outputJson, outputCSV)
    
if __name__ == "__main__":
    main()
