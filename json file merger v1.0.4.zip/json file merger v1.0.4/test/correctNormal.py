import json
import pandas as pd
from pandas import json_normalize

with open('kilroy_p1.json') as f:
    variable1 =json.load(f)
    variable2 = json_normalize(data=variable1['results'], record_path='bills', meta=['id', 'member_uri', 'name','num_results', 'offset'])

print(variable2)
