import os

## get number of json files under directory and fill
#  a list that contains all json file names
#
# @param    jsonList
#           a list contain json file names          

def countJson(jsonList):
    currentDir = ""
    jsonCounter = 0
    fileList = []
    
    currentDir = os.getcwd()
    fileList = os.listdir()
    print("Current Directory: ", currentDir, "\n")
    print("Files under this directory: ")
    for file in fileList:
        print(file)
        if(".json" in file):
            jsonCounter += 1
            jsonList.append(file)
    print("\nTotal number of file: ", len(fileList))
    print("Total number of json: ", jsonCounter, "\n")
