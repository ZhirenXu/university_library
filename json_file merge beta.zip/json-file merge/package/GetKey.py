import sys

## get desired key for json file.
# @return   keyword
#           the desired key of json dictionary in string
def getKey():
    print("Please enter the key of data that you want to get from json files: ", end = "")
    keyword = input()
    
    return keyword
    
