import os
import json

## merge all elements in billDetailList into target file, under the value of key
# @param    key
#           the key of a tuple in target json
# @param    file
#           the target json file
# @param    billDetailList
#           a list contains all values for tuple with @key as key
def mergeJson(key, file, billDetailList):
    #open file, w will wipe the file! bug!
    #tar = open(file, 'w')
    #find dict with key @key, change the value in that tuple
    jsonContent = json.load(tar)
    jsonContentResults = jsonContent["results"]
    for dict_ in jsonContentResults:
        if(key in dict_):
            for billTuple in billDetailList:
                dict_.update(billTuple)
            break
    #close file
    tar.close()
