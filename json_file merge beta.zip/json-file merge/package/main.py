import sys
import GetKey
import CountJson
import GetJsonData
import MergeJson
def main():
    key = ""
    jsonList = []
    billDetailList = []
    i = 0
    # ask for desired keys that contain useful data
    key = GetKey.getKey()
    # show how many files in and scraped keyword
    CountJson.countJson(jsonList)
    # open json file one by one
    for json in jsonList:
        # get Json header(category name), data into seperate list
        print("Current File: ", json, end = "")
        GetJsonData.getJsonData(key, json, billDetailList)
        print("    ...Done\n")
    # merge bill detain into one json
    print("Total number of json: ", len(jsonList), "    ", "Total number of bills scraped: ", len(billDetailList))
    #MergeJson.mergeJson(key, jsonList[0], billDetailList)

if __name__ == "__main__":
    main()
