******Metadata Scrapper v1.1.0******
Author: Zhiren Xu
Publish data: 3/20/20

Instruction:
	1. put csv file contain metadata's url in 'package' folder
	2. run 'metaData_scraper_v1.1.0.py'
	3. follow instructions on display
