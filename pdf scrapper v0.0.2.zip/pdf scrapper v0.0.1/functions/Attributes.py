import sys
from functions import AttributesList

## let client choose attributes and output its contents as a list
# @param    attribArg
#           arg, a list contain text name of attributions
# @return   attrs
#           a list of number represent attributes
def getAttributesList(*attribArg):
    attrs = []
    i = 0

    print("Please choose what attribute you want to scrape.", end = "")
    print(" Enter by numbers, without blank space in between.\n")
    for attrib in attribArg[0]:
        print(i, ". ", attrib)
        i = i + 1
    i = 0
    print("5 .  ALL of above\n")
    print("Please enter your choice: ", end = "")
    userInput = input()
    num = int(userInput)
    if num < 5:
        while num > 0:
            choice = num % 10
            attrs.append(choice)
    else:
        while i < num:
            attrs.append(i)
            i= i + 1
    return attrs

## transfer number of attributes to text
# @param    attribsNum
#           arg, a list contain numbers that represent attributes
# @return   attribText
#           a lsit of atrribs
def getAttribInText(*attribsNum):
    attribText = []
    attribsMap = {}
    i = 0
    
    for attrib in AttributesList.attribs:
        attribsMap[i] = attrib
        i = i + 1
    for num in attribsNum[0]:
        attribText.append(attribsMap[num])
    return attribText

## get value of each attribute
# @param    docInfo
#           a DocumentInfomation subject whcih contain all metadata
# @param    *attribsNum
#           arg, a list contain numbers that represent attributes
# @return   data
#           a list of metadata
def getAttribValue(docInfo, *attribsName):
    rawData = {}
    data = []
    
    rawData["author"] = str(docInfo.author)
    rawData["creator"] = str(docInfo.creator)
    rawData["producer"] = str(docInfo.producer)
    rawData["title"] = str(docInfo.title)
    rawData["subject"] = str(docInfo.subject)

    for attrib in attribsName[0]:
        data.append(rawData[attrib])
    return data

def getXmpValue(xmpMetaData):
    print("dc_contributor: ", xmpMetaData.dc_contributor)
    print("dc_date: ", xmpMetaData.dc_date)
    print("dc_language: ", xmpMetaData.dc_language)
    print("dc_title: ", xmpMetaData.dc_title)
    print("dc_description: ", xmpMetaData.dc_description)
