attribs = ["author", "creator", "producer", "subject", "title"]
