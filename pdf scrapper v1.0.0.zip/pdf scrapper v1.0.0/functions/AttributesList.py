attribs = ["author", "creator", "producer", "subject", "title", "page number", "content"]
