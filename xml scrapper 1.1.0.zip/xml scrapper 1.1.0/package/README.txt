XML Scrapper for Lantern Archieve v1.1.0

Change log:
	accomondate errors so program can keep running even if input file is incorrect
	change the instruction output
	allow user to choose what to do when fail to get attributes
	fix typo

Note: All test file is in "file" folder. Copy them to "package" folder for trial run.

Instruction:
	0. Copy all target xml files under "package" folder
	1. Double click "main.py" to run
	2. The program will ask you for a template csv file. Put all attributes in the first row. One attribute per cell.
	3. Type in an output csv file name
	4. Type what you want program to do when can't read attributes
	5. Wait til it finishes. Output file will be generate in the same folder. Files that fail to get attributes will have blank cells.
	