XML Scrapper for Latern Archieve v1.0.0

Instruction:
	0. Copy all target xml files under "package" folder
	1. Double click "main.py" to run
	2. The program will ask you for a template csv file.Put all attributes in the first row. One attribute per cell.
	3. Type in an output csv file name
	4. Wait til it finishes. Output file will be generate in the same folder.
	