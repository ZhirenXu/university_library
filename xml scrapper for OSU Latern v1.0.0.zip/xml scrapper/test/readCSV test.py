import unittest
from package import ReadCSV

class TestReadCSV(unittest.TestCase):

    def test_read_csv(self):
        csv = "template.csv"
        attrs = []
        print("start testing...")    
        attrs = ReadCSV.readCSV(csv)
        print(attrs)

if __name__ == '__main__':
    unittest.main()
